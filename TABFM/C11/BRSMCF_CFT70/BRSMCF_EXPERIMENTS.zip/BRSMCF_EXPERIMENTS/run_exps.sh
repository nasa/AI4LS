#!/bin/bash

for s in $(ls run_POST*.sh)
do
	sbatch  --gres=gpu:1 ./$s
done

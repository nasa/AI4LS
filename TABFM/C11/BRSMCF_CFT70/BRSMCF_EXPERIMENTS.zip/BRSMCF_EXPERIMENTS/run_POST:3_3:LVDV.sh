#!/bin/bash
python -u c11_regression.py DATA/POST:3_3:LVDV.csv RESULTS/reg_rf_vs_tabpfn_POST:3_3:LVDV.csv

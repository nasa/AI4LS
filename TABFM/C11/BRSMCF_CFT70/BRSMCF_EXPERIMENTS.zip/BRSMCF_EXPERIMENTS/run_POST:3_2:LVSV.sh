#!/bin/bash
python -u c11_regression.py DATA/POST:3_2:LVSV.csv RESULTS/reg_rf_vs_tabpfn_POST:3_2:LVSV.csv
